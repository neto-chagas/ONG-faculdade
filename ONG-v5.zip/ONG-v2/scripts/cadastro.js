window.onload = function() {
  document.getElementById("formCadastro").addEventListener("submit", function(event){
    event.preventDefault();

    const formCadastro = event.target;

    const nomeCadastro = formCadastro.nome.value;
    const sobrenomeCadastro = formCadastro.sobrenome.value;
    const emailCadastro = formCadastro.email.value;
    const senhaCadastro = formCadastro.senha.value;

    // Limpa mensagens de erro anteriores
    const errorMessages = document.getElementsByClassName('error-message');
    while(errorMessages[0]) {
      errorMessages[0].parentNode.removeChild(errorMessages[0]);
    }

    // Validação do nome
    if (!nomeCadastro) {
      addErrorMessage(formCadastro.nome, "Por favor, insira o nome.");
    }

    // Validação do sobrenome
    if (!sobrenomeCadastro) {
      addErrorMessage(formCadastro.sobrenome, "Por favor, insira o sobrenome.");
    }

    // Validação do email
    if (!emailCadastro || !validateEmail(emailCadastro)) {
      addErrorMessage(formCadastro.email, "Por favor, insira um email válido.");
    }

    // Validação da senha
    if (!senhaCadastro || senhaCadastro.length < 8) {
      addErrorMessage(formCadastro.senha, "A senha deve ter pelo menos 8 caracteres.");
    }

    console.log("o nome é: " + nomeCadastro);
    console.log("o sobrenome é: " + sobrenomeCadastro);
    console.log("o email é: " + emailCadastro);
    console.log("a senha é: " + senhaCadastro);
  });
}

function addErrorMessage(inputElement, message) {
  const errorMessage = document.createElement('div');
  errorMessage.classList.add('error-message');
  errorMessage.textContent = message;
  inputElement.parentNode.insertBefore(errorMessage, inputElement.nextSibling);
}

function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}
