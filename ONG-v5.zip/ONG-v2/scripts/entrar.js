window.onload = function() {
  document.getElementById("formEntrar").addEventListener("submit", function(event){
    event.preventDefault();

    const formEntrar = event.target;

    const emailEntrar = formEntrar.email.value;
    const senhaEntrar = formEntrar.senha.value;

    // Limpa mensagens de erro anteriores
    const errorMessages = document.getElementsByClassName('error-message');
    while(errorMessages[0]) {
      errorMessages[0].parentNode.removeChild(errorMessages[0]);
    }

    // Validação do email
    if (!emailEntrar || !validateEmail(emailEntrar)) {
      addErrorMessage(formEntrar.email, "Por favor, insira um email válido.");
    }

    // Validação da senha
    if (!senhaEntrar || senhaEntrar.length < 8) {
      addErrorMessage(formEntrar.senha, "A senha deve ter pelo menos 8 caracteres.");
    }

    console.log("o email é: " + emailEntrar);
    console.log("a senha é: " + senhaEntrar);
  });
}

function addErrorMessage(inputElement, message) {
  const errorMessage = document.createElement('div');
  errorMessage.classList.add('error-message');
  errorMessage.textContent = message;
  inputElement.parentNode.insertBefore(errorMessage, inputElement.nextSibling);
}

function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}
